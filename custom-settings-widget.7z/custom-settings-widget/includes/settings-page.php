<?php
if (!defined('ABSPATH')) {
    exit;
}

function cswp_settings_page() {
    ?>
    <div class="wrap">
        <h1>Custom Settings Page</h1>
        <form method="post" action="options.php" enctype="multipart/form-data">
            <?php settings_fields('cswp_settings_group'); ?>
            <?php $options = get_option('cswp_settings'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Title</th>
                    <td><input type="text" name="cswp_settings[title]" value="<?php echo esc_attr($options['title'] ?? ''); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Description</th>
                    <td><textarea name="cswp_settings[description]"><?php echo esc_textarea($options['description'] ?? ''); ?></textarea></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Editor Content</th>
                    <td><?php wp_editor($options['editor_content'] ?? '', 'cswp_settings_editor_content', array('textarea_name' => 'cswp_settings[editor_content]')); ?></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Date</th>
                    <td><input type="date" name="cswp_settings[date]" value="<?php echo esc_attr($options['date'] ?? ''); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Image</th>
                    <td>
                        <input type="hidden" name="cswp_settings[image]" id="cswp_settings_image" value="<?php echo esc_attr($options['image'] ?? ''); ?>" />
                        <input type="button" class="button-secondary" id="cswp_settings_image_button" value="Upload Image" />
                        <div id="cswp_settings_image_preview"><?php if (!empty($options['image'])) { echo '<img src="' . esc_url($options['image']) . '" style="max-width:100%;">'; } ?></div>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Color Picker</th>
                    <td><input type="color" name="cswp_settings[color]" value="<?php echo esc_attr($options['color'] ?? '#ffffff'); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}
