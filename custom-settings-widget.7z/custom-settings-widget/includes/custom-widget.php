<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class CSWP_Custom_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'cswp_custom_widget',
            __('Custom Widget', 'text_domain'),
            array('description' => __('A Custom Widget', 'text_domain'))
        );
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];
        ?>
        <div style="background-color: <?php echo esc_attr($instance['color_picker']); ?>;">
            <?php if (!empty($instance['title'])) {
                echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
            } ?>
            <p><?php echo esc_html($instance['description']); ?></p>
            <div><?php echo wp_kses_post($instance['editor_content']); ?></div>
            <p><?php echo esc_html($instance['date']); ?></p>
            <?php if (!empty($instance['image'])) { ?>
                <img src="<?php echo esc_url($instance['image']); ?>" alt="">
            <?php } ?>
        </div>
        <?php
        echo $args['after_widget'];
    }

    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : '';
        $description = !empty($instance['description']) ? $instance['description'] : '';
        $editor_content = !empty($instance['editor_content']) ? $instance['editor_content'] : '';
        $date = !empty($instance['date']) ? $instance['date'] : '';
        $image = !empty($instance['image']) ? $instance['image'] : '';
        $color_picker = !empty($instance['color_picker']) ? $instance['color_picker'] : '#ffffff';
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>">Title:</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('description')); ?>">Description:</label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('description')); ?>" name="<?php echo esc_attr($this->get_field_name('description')); ?>"><?php echo esc_textarea($description); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('editor_content')); ?>">Editor Content:</label>
            <?php
            wp_editor($editor_content, $this->get_field_id('editor_content'), array(
                'textarea_name' => $this->get_field_name('editor_content'),
                'textarea_rows' => 10,
            ));
            ?>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('date')); ?>">Date:</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('date')); ?>" name="<?php echo esc_attr($this->get_field_name('date')); ?>" type="date" value="<?php echo esc_attr($date); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('image')); ?>">Image:</label>
            <input class="widefat image-url" id="<?php echo esc_attr($this->get_field_id('image')); ?>" name="<?php echo esc_attr($this->get_field_name('image')); ?>" type="text" value="<?php echo esc_attr($image); ?>">
            <input type="button" class="button upload-image" value="Upload Image">
            <div class="image-preview" style="margin-top: 10px;"><?php if (!empty($image)) { echo '<img src="' . esc_url($image) . '" style="max-width:100%;">'; } ?></div>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('color_picker')); ?>">Color Picker:</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('color_picker')); ?>" name="<?php echo esc_attr($this->get_field_name('color_picker')); ?>" type="color" value="<?php echo esc_attr($color_picker); ?>">
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
        $instance['description'] = (!empty($new_instance['description'])) ? sanitize_text_field($new_instance['description']) : '';
        $instance['editor_content'] = (!empty($new_instance['editor_content'])) ? $new_instance['editor_content'] : '';
        $instance['date'] = (!empty($new_instance['date'])) ? sanitize_text_field($new_instance['date']) : '';
        $instance['image'] = (!empty($new_instance['image'])) ? esc_url_raw($new_instance['image']) : '';
        $instance['color_picker'] = (!empty($new_instance['color_picker'])) ? sanitize_hex_color($new_instance['color_picker']) : '';

        // Server-side validation
        if (!ctype_alpha($instance['title'])) {
            $instance['title'] = $old_instance['title'];
        }

        if (!ctype_alnum($instance['description'])) {
            $instance['description'] = $old_instance['description'];
        }

        return $instance;
    }
}

function cswp_register_custom_widget() {
    register_widget('CSWP_Custom_Widget');
}

add_action('widgets_init', 'cswp_register_custom_widget');
