<?php
/*
Plugin Name: Custom Settings and Widget Plugin
Description: A custom plugin to create settings and widget.
Version: 1.0
Author: Your Name
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Include necessary files
include(plugin_dir_path(__FILE__) . 'includes/settings-page.php');
include(plugin_dir_path(__FILE__) . 'includes/custom-widget.php');

// Register settings
function cswp_register_settings() {
    register_setting('cswp_settings_group', 'cswp_settings');
}

add_action('admin_init', 'cswp_register_settings');

// Register settings page
function cswp_add_admin_menu() {
    add_menu_page('Custom Settings', 'Custom Settings', 'manage_options', 'custom-settings', 'cswp_settings_page', 'dashicons-admin-generic');
}

add_action('admin_menu', 'cswp_add_admin_menu');

// Register widget
function cswp_register_widget() {
    register_widget('CSWP_Custom_Widget');
}

add_action('widgets_init', 'cswp_register_widget');

// Enqueue scripts and styles
function cswp_enqueue_assets($hook_suffix) {
    if ($hook_suffix === 'toplevel_page_custom-settings') {
        wp_enqueue_media();
        wp_enqueue_script('cswp-media-uploader', plugin_dir_url(__FILE__) . 'assets/media-uploader.js', array('jquery'), null, true);
    }
    if ($hook_suffix == 'widgets.php') {
        wp_enqueue_media();
        wp_enqueue_script('cswp-widget-media-uploader', plugin_dir_url(__FILE__) . 'assets/widget-media-uploader.js', array('jquery'), null, true);
    }
    // Uncomment the following line if you have a styles.css file
    // wp_enqueue_style('cswp-styles', plugin_dir_url(__FILE__) . 'assets/styles.css');
}

add_action('admin_enqueue_scripts', 'cswp_enqueue_assets');

// AJAX handler for getting image URL
add_action('wp_ajax_cswp_get_image', 'cswp_get_image');
function cswp_get_image() {
    $attachment_id = absint($_GET['id']);
    $image = wp_get_attachment_image_src($attachment_id, 'medium');
    if (!empty($image)) {
        wp_send_json_success($image[0]);
    } else {
        wp_send_json_error();
    }
}

// Activation hook
function cswp_activate() {
    // Actions to perform on plugin activation
}

register_activation_hook(__FILE__, 'cswp_activate');

// Deactivation hook
function cswp_deactivate() {
    // Actions to perform on plugin deactivation
}

register_deactivation_hook(__FILE__, 'cswp_deactivate');
