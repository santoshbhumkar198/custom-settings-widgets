jQuery(document).ready(function ($) {
  var image_frame;

  $("#cswp_settings_image_button").click(function (e) {
    e.preventDefault();

    if (image_frame) {
      image_frame.open();
      return;
    }

    image_frame = wp.media({
      title: "Select Media",
      multiple: false,
      library: {
        type: "image",
      },
    });

    image_frame.on("select", function () {
      var selection = image_frame.state().get("selection").first().toJSON();
      var image_url = selection.url;
      var image_id = selection.id;

      $("#cswp_settings_image").val(image_id);
      Refresh_Image(image_id);
    });

    image_frame.open();
  });

  function Refresh_Image(the_id) {
    var data = {
      action: "cswp_get_image",
      id: the_id,
    };

    $.get(ajaxurl, data, function (response) {
      if (response.success) {
        $("#cswp_settings_image_preview").html(
          '<img src="' + response.data + '" style="max-width:100%;">'
        );
      }
    });
  }
});
