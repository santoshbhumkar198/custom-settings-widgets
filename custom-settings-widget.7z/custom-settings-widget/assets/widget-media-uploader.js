jQuery(document).ready(function ($) {
  $(document).on("click", ".upload-image", function (e) {
    e.preventDefault();

    // Store the button object in a variable
    var button = $(this);

    // Create a wp.media object
    var custom_uploader = wp.media({
      title: "Select Image",
      button: {
        text: "Use this image",
      },
      multiple: false,
    });

    // When an image is selected
    custom_uploader.on("select", function () {
      var attachment = custom_uploader
        .state()
        .get("selection")
        .first()
        .toJSON();

      // Set the image URL to the previous input field with class .image-url
      button.prev(".image-url").val(attachment.url);

      // Display the image preview in the next element with class .image-preview
      button
        .next(".image-preview")
        .html('<img src="' + attachment.url + '" style="max-width:100%;">');
    });

    // Open the media uploader dialog
    custom_uploader.open();
  });
});
